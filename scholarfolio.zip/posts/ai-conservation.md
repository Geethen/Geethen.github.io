# Can AI Save the Pangolin?

The pangolin is the world's most trafficked mammal. Poachers operate in vast, remote areas where park rangers simply cannot be everywhere at once. This is where Edge AI comes in.

## The Tech Stack

We deployed low-power cameras powered by Raspberry Pis and NVIDIA Jetson Nanos. These devices run object detection models locally.

### Challenges

1.  **Power**: Batteries must last months.
2.  **Connectivity**: No 4G/5G. We use LoRaWAN for low-bandwidth alerts.
3.  **False Positives**: Wind blowing grass should not trigger an alert.

## Results

Our model, a quantized MobileNetV3, achieved 92% recall on detecting humans and vehicles, significantly reducing the response time for rangers.

> "Technology is not the solution, but it is a powerful amplifier of human effort."

By combining local knowledge with real-time data, we are turning the tide against poaching.