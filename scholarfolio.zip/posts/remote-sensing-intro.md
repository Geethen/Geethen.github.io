# Getting Started with Multispectral Satellite Imagery

Remote sensing is transforming ecology. We no longer need to rely solely on expensive field expeditions to monitor habitat changes. With satellites like Sentinel-2 and Landsat, we can observe the entire planet every few days.

## Why Multispectral?

Human eyes only see Red, Green, and Blue (RGB). Satellites see much more, including Near-Infrared (NIR) and Shortwave-Infrared (SWIR).

Vegetation reflects NIR light strongly due to the cell structure of leaves. We can use this to calculate indices like NDVI (Normalized Difference Vegetation Index):

$$ NDVI = \frac{NIR - Red}{NIR + Red} $$

## Python Tools

To get started, I recommend the following stack:
- **Rasterio**: For reading GeoTIFFs
- **Geopandas**: For vector data (shapefiles)
- **Earth Engine API**: For accessing petabytes of data without downloading it.

```python
import rasterio
import matplotlib.pyplot as plt

# Open a Sentinel-2 band
with rasterio.open('sentinel2_band8.tif') as src:
    nir = src.read(1)

plt.imshow(nir, cmap='viridis')
plt.show()
```

Stay tuned for the next post where we'll train a CNN to detect deforestation!