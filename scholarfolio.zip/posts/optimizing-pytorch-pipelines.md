# Optimizing PyTorch Pipelines

Training deep learning models can be painfully slow. Here are a few tips to speed up your PyTorch code.

## 1. Use Mixed Precision

Using `torch.cuda.amp` can significantly reduce memory usage and speed up training on modern GPUs (Volta+).

```python
# Example of Automatic Mixed Precision
scaler = torch.cuda.amp.GradScaler()

with torch.cuda.amp.autocast():
    outputs = model(inputs)
    loss = criterion(outputs, targets)

scaler.scale(loss).backward()
scaler.step(optimizer)
scaler.update()
```

## 2. Pin Memory

When using a DataLoader, always set `pin_memory=True` if you are training on a GPU. This allows faster transfer from CPU RAM to GPU VRAM.

## Summary

Small tweaks in your data pipeline often yield better ROI than trying to optimize the model architecture itself.