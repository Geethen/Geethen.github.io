import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Hero } from './components/Hero';
import { ResearchList } from './components/ResearchList';
import { BlogList } from './components/BlogList';
import { BlogPostViewer } from './components/BlogPostViewer';
import { ChatBot } from './components/ChatBot';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Hero />} />
          <Route path="/research" element={<ResearchList />} />
          <Route path="/blog" element={<BlogList />} />
          <Route path="/blog/:slug" element={<BlogPostViewer />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        {/* Floating Chat Bot is available on all pages */}
        <ChatBot />
      </Layout>
    </HashRouter>
  );
};

export default App;